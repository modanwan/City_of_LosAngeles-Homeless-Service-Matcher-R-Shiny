# DSO-545-Final-Project-Group-14
USC Marshall MSBA DSO 545 Final Project Folder: Group 14
Group Members: Mohammad Ganji, Modan Wang, Muhammad Musthofa, Naiyuan Xiao, Wei Tang, Yufei Wang

#DataSet(6 datasets):
1. Census-Tracts
2. Council-Districts
3. calls311.RData
4. crime.RData
5. homeless_count.RData
6. unit_data_for_regression.csv

#R Shiny Dashboard File:
project dashboard.R

(Our dashboards inlcude basic data description, regression analysis and geospatial analysis.)

#before use
Please include all those code file and data files in one folder, Thank you~

